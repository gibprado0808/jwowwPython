#kwargs and args

# nums = [1,2,3]
# s = 0
# for n in nums:
#     print(n, end=" ")
#     # s= s + n

# def calculate(*nums):
#     s = 0
#     for n in nums:
#         s = s+ n
#     return s
# s = calculate(1,2,3,4,5,6,7,8,9)
# print(s)

#recursion

# def factorial(n):
