purchases = [
    ("C1", "Laptop", 1200),
    ("C2", "Laptop", 950),
    ("C1", "Mouse", 25),
    ("C3", "Keyboard", 75),
    ("C2", "Mouse", 30),
    ("C3", "Laptop", 1200),
    ("C1", "Keyboard", 50),
    ("C2", "Keyboard", 60),
    ("C3", "Mouse", 20)
]

count_dict = {}
for item in purchases:
    if item[1] in count_dict:
        count_dict[item[1]] += 1
    else:
        count_dict[item[1]] = 1

print(count_dict)

