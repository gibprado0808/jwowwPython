#
# list = ["apple", "banana", "cherry"]
# fruits = ("apple", "banana", "cherry")
# sala_set = {"tv", "sofa", "chair"}
#
#
# list[1] = "durian"
# fruits[1] = "banana"
# print(list)
# print(fruits[2])

# fruits = [
#     ["apple", "banana", "cherry"]
#     ["guava", "grapes", "mango"]
# ]

# def wordbank():
#
#     ask = 'y'.lower()
#     while ask == 'y':
#      add = input("Enter a word: ")

# wordbank = []
#
# ask = 'y'
# while ask == 'y':
#
#     word = input("Enter a word: ")
#     wordbank.append(word)
#
#     choice = input("Would you like to enter more word? (y/n): ").lower()
#
#     if choice == 'no'.lower():
#         print("words in the list: ")
#         for word in wordbank:
#             print(word)
#
#         lastword = wordbank[-1]
#
#         frequency = wordbank.count(lastword)
#         print(f"\nLast word: {lastword}\nFrequency: {frequency}")



#set

thisset = {"apple", "banana", "cherry"}
thisset.add("guava")
print(thisset)