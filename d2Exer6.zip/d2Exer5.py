# def greeting():
#     print("hello")
#
#
# greeting()
#
# def greet_with_name(name):
#     salary = 100
#     print(f"Hello, {name}!")
#     return salary
# name = input("What is your name? ")
# value_from_function = greet_with_name(name)
# print(value_from_function)
from itertools import product


# def summation(n):
#     i = 1
#     s = 0
#      while i <= n:
#         s += i
#         i += 1
#     return s

# number = int(input("Enter a number: ")) print(f"The summation of {number} is {summation(number)}")

# ask = 'Y'.lower()

# def factorial(num):
#     product = 1
#     for i in range(1, num+1):
#         product *= i
#     return product
# result = factorial(5)
# print(factorial(5))


# def add ():
#     num = 5+1
#     print(num)
#
# add()

# def sum(n):
#     s = 4
#     s = s + n
#     print(s)
#
# s = 0
# sum(4)