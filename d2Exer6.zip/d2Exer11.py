#dictionary

dict = {
    "brand":"Toyota",
    "model": "Fortuner",
    "year":2021,

}

#print (dict ["year"])

year = dict["year"]
print(year)

for k, v in dict.items():
    print(f"{k.title}: {v}")