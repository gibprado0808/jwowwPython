#tuple
mytuple = tuple()
questions = {

    ('Which is the only continent that has land in all four hemispheres', 'Africa'),
    ('How many hearts does an octopus have?', 'Three'),
    ('Which planet in the solar system has the most natural moons?', 'Saturn'),
    ('What is the primary base ingredient in traditional guacamole?', 'Avocado'),
    ('In the Harry Potter series, what are the four words that make up Harrys?', 'The Boy Who Lived')
}

for questions, answer in questions:
    print(questions)